<?php
$cari=$_GET['cari'];
header("location: daftar_out.php?cari=$cari");
?>
