<?php
$cari=$_GET['cari'];
header("location: daftar_anggota.php?cari=$cari");
?>
