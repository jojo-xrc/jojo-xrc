<?php

  $conn = mysqli_connect('localhost','root','','cash') or die($conn);

?>
